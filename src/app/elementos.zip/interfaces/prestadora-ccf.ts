export interface PrestadorasCCF {
    codigo: string;
    label: string;
}