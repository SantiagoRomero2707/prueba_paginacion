export interface TipoDocumento{
    id:number;
    label: string;
    tipoDocumento: string;
}