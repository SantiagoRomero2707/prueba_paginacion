export interface CodigoRiesgos{
    code:string | null;
    label:string;
};
