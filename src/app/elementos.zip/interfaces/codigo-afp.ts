export interface CodigoAFP{
    code:string;
    label:string;
};