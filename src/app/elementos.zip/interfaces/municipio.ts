import { Departamentos } from "./departamento";

export interface Municipios{
    departamento: Departamentos;
    municipio: string;
    id: number;


}