export interface ModalidadPago{
    code:string;
    label:string;
}