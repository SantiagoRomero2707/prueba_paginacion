export interface CodigoCCF{
    code:string;
    label:string;
};