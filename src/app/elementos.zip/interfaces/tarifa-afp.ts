export interface TarifaAFP {
    code:string | null;
    label:string;
};