export interface ClaseRiesgo{
    code:string | null;
    label:string;
};