export interface IndicadorTarifaEspecial{
    code:string;
    label:string;
};
