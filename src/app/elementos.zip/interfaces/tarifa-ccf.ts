export interface TarifaCcf{
    code:string;
    label:string;
};