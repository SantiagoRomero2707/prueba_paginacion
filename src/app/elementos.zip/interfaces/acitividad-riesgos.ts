export interface ActividadRiesgos{
    code: string;
    label: string;
    showButton: boolean;
}