export interface CodigoEPS{
    code:string;
    label:string;
};
