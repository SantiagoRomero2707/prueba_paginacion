
export interface SubTipoCotizante{
    code:string;
    label:string;
}