export interface TipoCotizante {
    code:string;
    label:string;
}