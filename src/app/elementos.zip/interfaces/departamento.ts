export interface Departamentos{
    departamento: string;
    id: number;
}