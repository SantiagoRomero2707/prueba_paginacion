export interface ActividadEconomica{
    code:string;
    label:string
}