export interface TarifaEps{
    code:string
    label:string;
}