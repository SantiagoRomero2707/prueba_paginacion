export interface Sucursal{
    code:string
    label:string;
}