import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actividad-riesgo-modal',
  templateUrl: './actividad-riesgo-modal.component.html',
  styleUrls: ['./actividad-riesgo-modal.component.scss'],
})
export class ActividadRiesgoModalComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
