import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actividad-economica-modal',
  templateUrl: './actividad-economica-modal.component.html',
  styleUrls: ['./actividad-economica-modal.component.scss'],
})
export class ActividadEconomicaModalComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
