import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tipo-documento-modal',
  templateUrl: './tipo-documento-modal.component.html',
  styleUrls: ['./tipo-documento-modal.component.scss'],
})
export class TipoDocumentoModalComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
