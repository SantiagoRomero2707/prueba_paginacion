import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-municipio-modal',
  templateUrl: './municipio-modal.component.html',
  styleUrls: ['./municipio-modal.component.scss'],
})
export class MunicipioModalComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
