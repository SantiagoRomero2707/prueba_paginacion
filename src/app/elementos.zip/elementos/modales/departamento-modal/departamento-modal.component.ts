import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-departamento-modal',
  templateUrl: './departamento-modal.component.html',
  styleUrls: ['./departamento-modal.component.scss'],
})
export class DepartamentoModalComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
